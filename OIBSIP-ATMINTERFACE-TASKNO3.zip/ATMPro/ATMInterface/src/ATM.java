import java.util.*;

public class ATM {
    private static Map<String, User> userDatabase = new HashMap<>();

    public static void main(String[] args) {
        populateDummyUsers();

        Scanner sc = new Scanner(System.in);
        System.out.println("======= Welcome to Advanced Java ATM =======");
        System.out.print("Enter User ID: ");
        String userId = sc.nextLine();
        System.out.print("Enter PIN: ");
        String pin = sc.nextLine();

        User user = userDatabase.get(userId);

        if (user != null && user.authenticate(pin)) {
            ATMService service = new ATMService(user, sc);
            service.showMenu();
        } else {
            System.out.println("❌ Invalid credentials. Access denied.");
        }

        sc.close();
    }

    private static void populateDummyUsers() {
        User u1 = new User("vaish123", "1234", 20000);
        User u2 = new User("john456", "4567", 15000);
        userDatabase.put(u1.getUserId(), u1);
        userDatabase.put(u2.getUserId(), u2);
    }

	public static Object getUserDatabase() {
		// TODO Auto-generated method stub
		return null;
	}
}
