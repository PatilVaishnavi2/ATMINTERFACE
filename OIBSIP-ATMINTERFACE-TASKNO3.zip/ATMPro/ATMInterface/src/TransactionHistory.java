import java.util.*;

public class TransactionHistory {
    private List<Transaction> transactions = new ArrayList<>();

    public void add(String type, double amount, String details) {
        transactions.add(new Transaction(type, amount, details));
    }

    public void show() {
        if (transactions.isEmpty()) {
            System.out.println("📂 No transactions yet.");
        } else {
            System.out.println("📜 Transaction History:");
            for (Transaction t : transactions) {
                System.out.println("  - " + t);
            }
        }
    }
}
