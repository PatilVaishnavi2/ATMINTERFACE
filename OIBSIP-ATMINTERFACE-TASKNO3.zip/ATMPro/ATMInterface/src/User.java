public class User {
    private String userId;
    private String pin;
    private double balance;
    private TransactionHistory history;

    public User(String userId, String pin, double balance) {
        this.userId = userId;
        this.pin = pin;
        this.balance = balance;
        this.history = new TransactionHistory();
    }

    public boolean authenticate(String pin) {
        return this.pin.equals(pin);
    }

    public String getUserId() {
        return userId;
    }

    public double getBalance() {
        return balance;
    }

    public void updateBalance(double amount) {
        this.balance += amount;
    }

    public TransactionHistory getHistory() {
        return history;
    }
}
