import java.util.Scanner;

public class ATMService {
    private User user;
    private Scanner scanner;

    public ATMService(User user, Scanner scanner) {
        this.user = user;
        this.scanner = scanner;
    }

    public void showMenu() {
        while (true) {
            printHeader();
            System.out.println("1️⃣  View Transaction History");
            System.out.println("2️⃣  Withdraw Money");
            System.out.println("3️⃣  Deposit Money");
            System.out.println("4️⃣  Transfer Funds");
            System.out.println("5️⃣  Check Balance");
            System.out.println("6️⃣  Quit");
            System.out.print("Select an option: ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1": user.getHistory().show(); break;
                case "2": withdraw(); break;
                case "3": deposit(); break;
                case "4": transfer(); break;
                case "5": System.out.println("💰 Current Balance: ₹" + user.getBalance()); break;
                case "6":
                    System.out.println("👋 Thank you for banking with us!");
                    return;
                default: System.out.println("❗ Invalid option. Please try again.");
            }
        }
    }

    private void printHeader() {
        System.out.println("\n=========================================");
        System.out.println("🧾 Welcome, " + user.getUserId());
        System.out.println("=========================================");
    }

    private void withdraw() {
        System.out.print("Enter amount to withdraw: ₹");
        double amount = readAmount();
        if (amount <= 0) return;

        if (amount > user.getBalance()) {
            System.out.println("⚠️ Insufficient balance.");
        } else {
            user.updateBalance(-amount);
            user.getHistory().add("Withdraw", amount, "Cash withdrawn");
            System.out.println("✅ Withdrawal successful.");
        }
    }

    private void deposit() {
        System.out.print("Enter amount to deposit: ₹");
        double amount = readAmount();
        if (amount <= 0) return;

        user.updateBalance(amount);
        user.getHistory().add("Deposit", amount, "Cash deposited");
        System.out.println("✅ Deposit successful.");
    }

    private void transfer() {
        System.out.print("Enter recipient ID: ");
        String recipientId = scanner.nextLine();
        System.out.print("Enter amount to transfer: ₹");
        double amount = readAmount();
        if (amount <= 0) return;

        if (recipientId.equals(user.getUserId())) {
            System.out.println("⚠️ Cannot transfer to self.");
            return;
        }

        User recipient = ATM.getUserDatabase().get(recipientId);
        if (recipient == null) {
            System.out.println("❌ Recipient not found.");
            return;
        }

        if (amount > user.getBalance()) {
            System.out.println("⚠️ Insufficient balance.");
        } else {
            user.updateBalance(-amount);
            recipient.updateBalance(amount);
            user.getHistory().add("Transfer", amount, "To " + recipientId);
            recipient.getHistory().add("Received", amount, "From " + user.getUserId());
            System.out.println("✅ Transfer completed to " + recipientId);
        }
    }

    private double readAmount() {
        try {
            double amt = Double.parseDouble(scanner.nextLine());
            if (amt <= 0) {
                System.out.println("❌ Invalid amount.");
                return -1;
            }
            return amt;
        } catch (NumberFormatException e) {
            System.out.println("❌ Invalid input. Enter a number.");
            return -1;
        }
    }
}
